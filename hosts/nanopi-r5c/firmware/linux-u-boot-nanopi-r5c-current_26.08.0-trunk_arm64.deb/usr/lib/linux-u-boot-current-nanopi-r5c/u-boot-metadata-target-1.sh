declare -a UBOOT_TARGET_BINS=('idbloader.img' 'u-boot.itb')
declare UBOOT_TARGET_MAKE='ROCKCHIP_TPL=/armbian/cache/sources/rkbin-tools/rk35/rk3568_ddr_1560MHz_v1.21.bin BL31=/armbian/cache/sources/rkbin-tools/rk35/rk3568_bl31_v1.44.elf spl/u-boot-spl u-boot.bin flash.bin'
declare UBOOT_TARGET_CONFIG="u-boot-config-target-1"
declare UBOOT_TARGET_DEFCONFIG="u-boot-defconfig-target-1"
